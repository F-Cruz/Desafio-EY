package com.herois.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiHeroisApplicationTests {

	@Test
	void contextLoads() {
	}

}
