package com.herois.api.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class HeroiTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
